#include "stdafx.h"
#include "StrategyUtils.h"
#include "Movement.h"
#include "FreeKick.h"

void FreeKick(Environment *env, RealEnvironment REnv)
{
	Vector2d Target;

	if (REnv.PlayTo == RIGHT_SIDE)
		if (REnv.IsBlueTeam) 
			if (env->whosBall == BLUE_BALL)
				FreeKickAtkL2R(env, REnv, &Target);
			else
				FreeKickDefL2R(env, REnv, &Target);
		else
			if (env->whosBall == YELLOW_BALL)
				FreeKickAtkL2R(env, REnv, &Target);
			else
				FreeKickDefL2R(env, REnv, &Target);
	else
		if (REnv.IsBlueTeam) 
			if (env->whosBall == BLUE_BALL)
				FreeKickAtkR2L(env, REnv, &Target);
			else
				FreeKickDefR2L(env, REnv, &Target);
		else
			if (env->whosBall == YELLOW_BALL)
				FreeKickAtkR2L(env, REnv, &Target);
			else
				FreeKickDefR2L(env, REnv, &Target);

	Target.m_x = Target.m_x/FIRA_LENGTH*PITCH_LENGTH/25.4;
	Target.m_y = Target.m_y/FIRA_WIDTH*PITCH_WIDTH/25.4;
	NavigateTo(env, REnv, Target);
}
void FreeKickAtkL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{	
	double x = env->currentBall.pos.x * 25.4;		//+-180
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	if (x > 1100)
		if (y > 900)
			TopLeftKickAtkL2R(env, REnv, Target);
		else
			TopRightKickAtkL2R(env, REnv, Target);
	else
		if (y > 900)
			BottomLeftKickAtkL2R(env, REnv, Target);
		else
			BottomRightKickAtkL2R(env, REnv, Target);
}

void FreeKickAtkR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	if (x > 1100)
		if (y > 900)
			TopLeftKickAtkR2L(env, REnv, Target);
		else
			TopRightKickAtkR2L(env, REnv, Target);
	else
		if (y > 900)
			BottomLeftKickAtkR2L(env, REnv, Target);
		else
			BottomRightKickAtkR2L(env, REnv, Target);
}
void FreeKickDefL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{	
	double x = env->currentBall.pos.x * 25.4;		//+-180
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	if (x > 1100)
		if (y > 900)
			TopLeftKickDefL2R(env, REnv, Target);
		else
			TopRightKickDefL2R(env, REnv, Target);
	else
		if (y > 900)
			BottomLeftKickDefL2R(env, REnv, Target);
		else
			BottomRightKickDefL2R(env, REnv, Target);
}
void FreeKickDefR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{	
	double x = env->currentBall.pos.x * 25.4;		//+-180
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	if (x > 1100)
		if (y > 900)
			TopLeftKickDefR2L(env, REnv, Target);
		else
			TopRightKickDefR2L(env, REnv, Target);
	else
		if (y > 900)
			BottomLeftKickDefR2L(env, REnv, Target);
		else
			BottomRightKickDefR2L(env, REnv, Target);
}

void BottomRightKickAtkL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line opposite centre spot
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//bottom left
			Target->m_x = 750;
			Target->m_y = 1000;
			Target->m_degphi = -30;
		}
		break;
	case P3 :
		{//Behind ball
			Target->m_x = x - 150;
			Target->m_y = y + 100;
			Target->m_degphi = -30;
		}
		break;
	case P4 :
		{//Kicker in front of ball
			Target->m_x = x + 70;
			Target->m_y = y;
			Target->m_degphi = 180;
		}
		break;
	case P5 :
		{//top middle
			Target->m_x = 1600;
			Target->m_y = 900;
		}
		break;
	default :
		{
		}
		break;
	}
}

void BottomRightKickAtkR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Top > 1100 for x
	//Left > 900 for y
	Target->m_degphi = 180;
	switch (REnv.RobotID)
	{
	case P1 :
		{// On goal line opposite penalty spot
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//bottom right
			Target->m_x = 750;
			Target->m_y = 1000;
			Target->m_degphi = -150;
		}
		break;
	case P3 :
		{//Behind Ball
			Target->m_x = x - 150;
			Target->m_y = y + 100;
			Target->m_degphi = 150;
		}
		break;
	case P4 :
		{//Kicker in front of ball
			Target->m_x = x + 70;
			Target->m_y = y;
			Target->m_degphi = 0;
		}
		break;
	case P5 :
		{//top middle
			Target->m_x = 1600;
			Target->m_y = 900;
		}
		break;
	default :
		{
		}
		break;
	}
}

void BottomRightKickDefL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{	
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line by right post
			Target->m_x = 100;
			Target->m_y = 800;
			Target->m_degphi = -45;
		}
		break;
	case P2 :
		{//PA middle
			Target->m_x = 300;
			Target->m_y = 900;
			Target->m_degphi = -75;
		}
		break;
	case P3 :
		{//Edge PA right bottom
			Target->m_x = 400;
			Target->m_y = 500;
		}
		break;
	case P4 :
		{//Behind Ball
			Target->m_x = x - 225;
			Target->m_y = y + 225;
			Target->m_degphi = -45;
		}
		break;
	case P5 :
		{//Behind Ball
			Target->m_x = x - 320;
			Target->m_y = y + 30;
		}
		break;
	default :
		{
		}
		break;
	}
}

void BottomRightKickDefR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 180;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line by right post
			Target->m_x = 100;
			Target->m_y = 800;
			Target->m_degphi = -45;
		}
		break;
	case P2 :
		{//PA middle
			Target->m_x = 300;
			Target->m_y = 900;
			Target->m_degphi = 135;
		}
		break;
	case P3 :
		{//Edge PA right bottom
			Target->m_x = 400;
			Target->m_y = 500;
		}
		break;
	case P4 :
		{//Behind Ball
			Target->m_x = x - 225;
			Target->m_y = y + 225;
			Target->m_degphi = -45;
		}
		break;
	case P5 :
		{//Behind Ball
			Target->m_x = x - 320;
			Target->m_y = y + 30;
		}
		break;
	default :
		{
		}
		break;
	}
}

void TopRightKickAtkL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line opposite centre spot
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//bottom left
			Target->m_x = 750;
			Target->m_y = 1000;
		}
		break;
	case P3 :
		{//bottom right
			Target->m_x = 850;
			Target->m_y = 800;
			Target->m_degphi = -45;
		}
		break;
	case P4 :
		{//Behind Ball
			Target->m_x = x - 150;
			Target->m_y = y - 100;
			Target->m_degphi = 30;
		}
		break;
	case P5 :
		{//Kicker in front of ball
			Target->m_x = x + 70;
			Target->m_y = y;
			Target->m_degphi = 150;
		}
		break;
	default :
		{
		}
		break;
	}
}

void TopRightKickAtkR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 180;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line opposite centre spot
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//bottom left
			Target->m_x = 750;
			Target->m_y = 1000;
		}
		break;
	case P3 :
		{//bottom right
			Target->m_x = 850;
			Target->m_y = 800;
			Target->m_degphi = 135;
		}
		break;
	case P4 :
		{//Behind Ball
			Target->m_x = x - 150;
			Target->m_y = y - 100;
			Target->m_degphi = -150;
		}
		break;
	case P5 :
		{//Kicker in front of ball
			Target->m_x = x + 70;
			Target->m_y = y;
			Target->m_degphi = -30;
		}
		break;
	default :
		{
		}
		break;
	}
}

void TopRightKickDefL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{	
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line right
			Target->m_x = 100;
			Target->m_y = 850;
			Target->m_degphi = -30;
		}
		break;
	case P2 :
		{//Edge PA bottom  left
			Target->m_x = 400;
			Target->m_y = 900;
			Target->m_degphi = -30;
		}
		break;
	case P3 :
		{//PA bottom right
			Target->m_x = 900;
			Target->m_y = 700;
			Target->m_degphi = -90;
		}
		break;
	case P4 :
		{//Behind Ball
			Target->m_x = x - 225;
			Target->m_y = y + 225;
			Target->m_degphi = -45;

		}
		break;
	case P5 :
		{//Behind Ball
			Target->m_x = x - 320;
			Target->m_y = y + 30;
		}
		break;
	default :
		{
		}
		break;
	}
}

void TopRightKickDefR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 180;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line right
			Target->m_x = 100;
			Target->m_y = 850;
			Target->m_degphi = 150;
		}
		break;
	case P2 :
		{//Edge PA bottom  left
			Target->m_x = 400;
			Target->m_y = 900;
			Target->m_degphi = 150;
		}
		break;
	case P3 :
		{//PA bottom right
			Target->m_x = 900;
			Target->m_y = 700;
		}
		break;
	case P4 :
		{//Behind Ball
			Target->m_x = x - 225;
			Target->m_y = y + 225;
		}
		break;
	case P5 :
		{//Behind Ball
			Target->m_x = x - 320;
			Target->m_y = y + 30;
			Target->m_degphi = -30;
		}
		break;
	default :
		{
		}
		break;
	}
}

void BottomLeftKickAtkL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//Behind Ball
			Target->m_x = x - 150;
			Target->m_y = y - 100;
			Target->m_degphi = 30;
		}
		break;
	case P3 :
		{//
			Target->m_x = 700;
			Target->m_y = 1000;
		}
		break;
	case P4 :
		{//Kicker in front of ball
			Target->m_x = x + 70;
			Target->m_y = y;
			Target->m_degphi = 150;
		}
		break;
	case P5 :
		{//Top half middle
			Target->m_x = 1600;
			Target->m_y = 900;
		}
		break;
	default :
		{
		}
		break;
	}
}

void BottomLeftKickAtkR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 180;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//Behind Ball
			Target->m_x = x - 150;
			Target->m_y = y - 100;
			Target->m_degphi = 30;
		}
		break;
	case P3 :
		{//
			Target->m_x = 700;
			Target->m_y = 1000;
		}
		break;
	case P4 :
		{//Kicker in front of ball
			Target->m_x = x + 70;
			Target->m_y = y;
			Target->m_degphi = 150;
		}
		break;
	case P5 :
		{//Top half middle
			Target->m_x = 1600;
			Target->m_y = 900;
		}
		break;
	default :
		{
		}
		break;
	}
}

void BottomLeftKickDefL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{	
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line bottom
			Target->m_x = 100;
			Target->m_y = 1000;
			Target->m_degphi = 45;
		}
		break;
	case P2 :
		{//PA bottom left
			Target->m_x = 300;
			Target->m_y = 1100;
			Target->m_degphi = 90;
		}
		break;
	case P3 :
		{//Edge PA bottom left
			Target->m_x = 400;
			Target->m_y = 1200;
			Target->m_degphi = 45;
		}
		break;
	case P4 :
		{//Behind Ball
			Target->m_x = x - 225;
			Target->m_y = y - 225;
			Target->m_degphi = 45;
		}
		break;
	case P5 :
		{//Behind Ball
			Target->m_x = x - 320;
			Target->m_y = y - 30;
		}
		break;
	default :
		{
		}
		break;
	}
}

void BottomLeftKickDefR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 180;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line bottom
			Target->m_x = 100;
			Target->m_y = 1000;
			Target->m_degphi = -135;
		}
		break;
	case P2 :
		{//PA bottom left
			Target->m_x = 300;
			Target->m_y = 1100;
			Target->m_degphi = -90;
		}
		break;
	case P3 :
		{//Edge PA bottom left
			Target->m_x = 400;
			Target->m_y = 1200;
			Target->m_degphi = -135;
		}
		break;
	case P4 :
		{//Behind Ball
			Target->m_x = x - 225;
			Target->m_y = y - 225;
			Target->m_degphi = -135;
		}
		break;
	case P5 :
		{//Behind Ball
			Target->m_x = x - 320;
			Target->m_y = y - 30;
		}
		break;
	default :
		{
		}
		break;
	}

}

void TopLeftKickAtkL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//bottom left
			Target->m_x = 1000;
			Target->m_y = 1100;
		}
		break;
	case P3 :
		{//bottom right
			Target->m_x = 700;
			Target->m_y = 800;
		}
		break;
	case P4 :
		{//Behind Ball
			Target->m_x = x - 150;
			Target->m_y = y + 100;
			Target->m_degphi = -30;
		}
		break;
	case P5 :
		{//Kicker in front of ball
			Target->m_x = x + 70;
			Target->m_y = y;
			Target->m_degphi = -150;
		}
		break;
	default :
		{
		}
		break;
	}
}

void TopLeftKickAtkR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 180;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//bottom left
			Target->m_x = 1000;
			Target->m_y = 1100;
		}
		break;
	case P3 :
		{//bottom right
			Target->m_x = 700;
			Target->m_y = 800;
		}
		break;
	case P4 :
		{//Behind Ball
			Target->m_x = x - 150;
			Target->m_y = y + 100;
			Target->m_degphi = -30;
		}
		break;
	case P5 :
		{//Kicker in front of ball
			Target->m_x = x + 70;
			Target->m_y = y;
			Target->m_degphi = -150;
		}
		break;
	default :
		{
		}
		break;
	}
}

void TopLeftKickDefL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{	
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line left
			Target->m_x = 100;
			Target->m_y = 1000;
			Target->m_degphi = 45;
		}
		break;
	case P2 :
		{//Edge of PA left
			Target->m_x = 400;
			Target->m_y = 1100;
			Target->m_degphi = 30;
		}
		break;
	case P3 :
		{//PA top
			Target->m_x = 300;
			Target->m_y = 900;
			Target->m_degphi = 45;
		}
		break;
	case P4 :
		{//Behind Ball
			Target->m_x = x - 225;
			Target->m_y = y - 225;
			Target->m_degphi = 45;
		}
		break;
	case P5 :
		{//Behind Ball
			Target->m_x = x - 320;
			Target->m_y = y - 30;
		}
		break;
	default :
		{
		}
		break;
	}
}

void TopLeftKickDefR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	double x = env->currentBall.pos.x * 25.4;		//+-180 for 250 mm away
	double y = env->currentBall.pos.y * 25.4;		//+-180

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 180;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line left
			Target->m_x = 100;
			Target->m_y = 1000;
			Target->m_degphi = -135;
		}
		break;
	case P2 :
		{//Edge of PA left
			Target->m_x = 400;
			Target->m_y = 1100;
			Target->m_degphi = -150;
		}
		break;
	case P3 :
		{//PA top
			Target->m_x = 300;
			Target->m_y = 900;
			Target->m_degphi = -135;
		}
		break;
	case P4 :
		{//Behind Ball
			Target->m_x = x - 225;
			Target->m_y = y - 225;
			Target->m_degphi = -135;

		}
		break;
	case P5 :
		{//Behind Ball
			Target->m_x = x - 320;
			Target->m_y = y - 30;
		}
		break;
	default :
		{
		}
		break;
	}
}
