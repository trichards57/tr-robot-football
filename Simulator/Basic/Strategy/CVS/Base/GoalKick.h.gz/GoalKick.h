void GoalKick(Environment *env, RealEnvironment REnv);
void GoalKickAtk(Environment *env, RealEnvironment REnv, Vector2d *Target);
void GoalKickDef(Environment *env, RealEnvironment REnv, Vector2d *Target);