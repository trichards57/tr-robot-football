void KickOff(Environment *env, RealEnvironment REnv);
void KickOffAtkL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void KickOffAtkR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void KickOffDefL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void KickOffDefR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
