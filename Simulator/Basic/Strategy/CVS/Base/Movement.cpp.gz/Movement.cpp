/*************************************************************************
This file contains movement commands for the robots

**************************************************************************/
#include "stdafx.h"
#include <stdlib.h>
#include <math.h>
#include "Geometry.h"
#include "StrategyUtils.h"
#include "Movement.h"
/*
Added P Birkin May 2006
*/

void NavigateTo(Environment *env, RealEnvironment REnv, Vector2d Target)
{
	/*
	Call to send the robot to the required position. 
	This is in all the positioning functions as a hook
	*/
	PositionToTarget(env, REnv, Target);
}
void PositionToTarget(Environment *env, RealEnvironment REnv, Vector2d Target)
{
	//Position the robot for place kicks, driving in a straight line
	//All speeds are hard-coded in this call

	Vector2d CurrentPos;
	double TargetAngle = 0;
	double ReqRotation  = 0;
	bool status = false;

	CurrentPos.m_x = env->home[REnv.RobotID].pos.x;	//In inches
	CurrentPos.m_y = env->home[REnv.RobotID].pos.y;	//Origin is bottom left of pitch
	//Convert from Vector3D to Vector2d

	double CurrentDistance = CurrentPos.GetDistanceTo(Target);		//In inches
	if (CurrentDistance <= .25)
	{//Must be there
		status = RotateAtTarget(env, REnv, Target);
	}
	else
	{//Drive there

		double CurrentAngle = env->home[REnv.RobotID].rotation;	//Cartesian angle
		double TargetX = Target.m_x - CurrentPos.m_x;
		double TargetY = Target.m_y - CurrentPos.m_y;
		ReqRotation = OrientationToTarget(TargetX, TargetY, CurrentAngle, REnv.PlayTo);

		if (abs(ReqRotation)> 20)
			PointToTarget(env, REnv, ReqRotation);	//Too big to take out by motion
		else
		{
			double DriveSpeed = 25;	//REnv.Speed;
			if (CurrentDistance <= .25)
			{
				DriveSpeed = 0;
			}
			else
				if (CurrentDistance <= 2)
					DriveSpeed = 1;
				else
					if (CurrentDistance <= 4)
						DriveSpeed = 3;
			
			double LeftDiff = 2;
			double RightDiff = 2;
			double sign = -1;	//-ve rotation going forward left > right
			if (ReqRotation > 0)
				sign = 1;		//+ve rotation going forward left < right
			
			double ReqRotation1 = abs(ReqRotation);
			if (ReqRotation1 > 10 && CurrentDistance > 10)
			{
				LeftDiff = -sign * LeftDiff;
				RightDiff = sign * RightDiff;
			}
			
			env->home[REnv.RobotID].velocityLeft = DriveSpeed + LeftDiff;
			env->home[REnv.RobotID].velocityRight = DriveSpeed + RightDiff;
		}
	}
}

bool RotateAtTarget(Environment *env, RealEnvironment REnv, Vector2d Target)
{//Point the robot at the target by rotating on the spot
	bool status = false;
	double CurrentAngle = env->home[REnv.RobotID].rotation;	//Cartesian angle
	double DiffAngle = Geometry::DegAngleDiff(CurrentAngle, Target.m_degphi);
	double sign = -1;
	if (DiffAngle > 0)
		sign = 1;
	double SpinSpeed = 5 * sign;
	if (abs(DiffAngle) < 3)
	{
		SpinSpeed = 0;
		status = true;
	}	
	else
		if (abs(DiffAngle) < 20)
		{
			SpinSpeed = sign;
		}	

	//Applied the brakes to stop rotation when pointing at the target position
	//taking the shortest path

	env->home[REnv.RobotID].velocityLeft = SpinSpeed;
	env->home[REnv.RobotID].velocityRight = -SpinSpeed;

	return status;
}

int OrientationToTarget(double TargetX, double TargetY, double CurrentAngle, int PlayTo)
{//Returns the required rotation to point the front of the robot facing the target 
	double TargetAngle = Geometry::Angle(TargetY, TargetX);
	TargetAngle = Geometry::ToDegrees(TargetAngle);
	TargetAngle = Geometry::DegCorrectAngle(TargetAngle);
	if (PlayTo == LEFT_SIDE)
		if (TargetY > 0)
				TargetAngle = -(180 - TargetAngle);
			else
				TargetAngle = 180 + TargetAngle;
    
	return (int)(Geometry::DegAngleDiff(TargetAngle, CurrentAngle));
}

int TurnToTarget(int ReqRotation, bool * FacingTarget)
{//Returns the shortest turn to point the robot at the target
	int ReqTurn;
	*FacingTarget = false;		

	if (ReqRotation > 90)
		ReqTurn = ReqRotation - 180;
	else
		if (ReqRotation > -90)
		{
			ReqTurn = ReqRotation;
			*FacingTarget = true;		//Front is facing target
		}
		else
			ReqTurn = 180 + ReqRotation;
	return ReqTurn;
}

bool PointToTarget(Environment *env, RealEnvironment REnv, double ReqRotation)
{//Point the robot at the target by rotating on the spot
	bool status = false;
	double sign = -1;
	if (ReqRotation > 0)
		sign = 1;
	ReqRotation = abs(ReqRotation);
	double SpinSpeed = 10*sign;
	if (ReqRotation < 4)
	{
		SpinSpeed = 1;
		status = true;
	}
	else
		if (ReqRotation < 15.0)
			SpinSpeed = 2*sign;
		else
			if (ReqRotation < 40.0)
				SpinSpeed = 3*sign;
	//Applied the brakes to stop rotation when pointing at the target position
	//taking the shortest path

	env->home[REnv.RobotID].velocityLeft = -SpinSpeed;
	env->home[REnv.RobotID].velocityRight = SpinSpeed;
    
	return status;
}

void DriveToTarget(Environment *env, RealEnvironment REnv, Vector2d Target)
{//Template for moving the robot to the target
	Vector2d CurrentPos;
	CurrentPos.m_x = env->home[REnv.RobotID].pos.x;	//In inches
	CurrentPos.m_y = env->home[REnv.RobotID].pos.y;	//Origin is bottom left of pitch

	double TargetX = Target.m_x - CurrentPos.m_x;
	double TargetY = Target.m_y - CurrentPos.m_y;
	double CurrentAngle = env->home[REnv.RobotID].rotation;	//Cartesian angle
	int ReqRotation = OrientationToTarget(TargetX, TargetY, CurrentAngle, REnv.PlayTo);

	bool FacingTarget = true;	//Always true after OrientationToTarget
	int ReqTurn = TurnToTarget(ReqRotation, &FacingTarget);

	MoveToTarget(env, REnv, ReqTurn, FacingTarget);
}

void MoveToTarget(Environment *env, RealEnvironment REnv, int ReqTurn, bool FacingTarget)
{//Template for moving the robot in the correct direction 
	int left = 0;
	int right = 0;
	double DifSpeedFactor = 1;

	if ((ReqTurn < -65) ||(ReqTurn > 65))
		DifSpeedFactor = 3.0;
	else
		if ((ReqTurn >= -65 && ReqTurn < -25) || (ReqTurn > 25 && ReqTurn <= 65))
			DifSpeedFactor = 1.5;
		else
			if ((ReqTurn >= -25 && ReqTurn < -5) || (ReqTurn > 5 && ReqTurn <= 25))
				DifSpeedFactor = 1.2;

	int DifSpeed = (int)(REnv.Speed / DifSpeedFactor);

	if (FacingTarget)
		if (ReqTurn < 0)
		{//-ve turn
			left = REnv.Speed;
			right = DifSpeed;
		}
		else
		{//+ve turn
			left = DifSpeed;
			right = REnv.Speed;
		}
	else		//Back to target
		if (ReqTurn < 0)
		{//-ve turn
			left = -DifSpeed;
			right = -REnv.Speed;
		}
		else
		{//+ve turn
			left = -REnv.Speed;
			right = -DifSpeed;
		}

	env->home[REnv.RobotID].velocityLeft = left;
	env->home[REnv.RobotID].velocityRight = right;
}

#ifdef _MERLIN
void MoveTo(int ReqRot , int ReqSpeed, int RobotID, Environment *env, bool forcefront)
{// Move somewhere on an arc on a wheel speed differential of 1.5 : 1.
 // New MoveTo for compatibility with old system
	
	int RobRot = (int)env->home[RobotID].rotation;
	
	double Rotate = Geometry::DegAngleDiff(ReqRot, RobRot);
	
	if (abs(Rotate) <=3)
		return;

	if(Geometry::DegAngleDiff(ReqRot, RobRot) < -25 && Geometry::DegAngleDiff(ReqRot, RobRot) > -145 
			|| 
		Geometry::DegAngleDiff(ReqRot, RobRot) > 25 && Geometry::DegAngleDiff(ReqRot, RobRot) < 145)
	{
		int left=0;
		int right=0;
		int DifSpeed = (int)(ReqSpeed / 1.5);

		if(Geometry::DegAngleDiff(ReqRot, RobRot) < -90)
		{
			left = -ReqSpeed;
			right = -DifSpeed;
		}
		else if(Geometry::DegAngleDiff(ReqRot, RobRot) < 0)
		{
			left = ReqSpeed;
			right = DifSpeed;
		}
		else if(Geometry::DegAngleDiff(ReqRot, RobRot) < 90)
		{
			left = DifSpeed;
			right = ReqSpeed;
		}
		else if(Geometry::DegAngleDiff(ReqRot, RobRot) < 180)
		{
			left = -DifSpeed;
			right = -ReqSpeed;
		}

		env->home[RobotID].velocityLeft=left;
		env->home[RobotID].velocityRight=right;

	}
	else
	{
		MoveToOld(ReqRot, ReqSpeed, RobotID, env, forcefront);
	}

}

void MoveToOld(int ReqRot , int ReqSpeed, int RobotID, Environment *env, bool forcefront)
{// Old MoveTo for compatibility with old system
	double MaxSpeed = (double)ReqSpeed;
	int RobRot = (int)env->home[RobotID].rotation;

	if(	(Geometry::DegAngleDiff(ReqRot, RobRot) >= 90)
		||
		(Geometry::DegAngleDiff(ReqRot, RobRot) <= -90))
	{
		MaxSpeed = -MaxSpeed;
		RobRot = (int)Geometry::DegCorrectAngle(180 + RobRot);			// make back to front
	}
	
	double e = Kp * Geometry::DegAngleDiff(ReqRot, RobRot);
	
	// Max speed from distance-speed curve
	double v = MaxSpeed;
	double V = 1;

	if(e !=0)
		V = 180.0 / fabs(e);
	else
		v = 127.0;	// avoids division by 0
	
	if( abs(v) > V){ v = (v/abs(v)) *  V; }

	env->home[RobotID].velocityLeft = v - e;
	env->home[RobotID].velocityRight = v + e;
}	

void RotateTo(int des_rot , int speed, int id,  Environment *env ,bool forcefront)
{// RotateTo for compatibility with old system
		double max_speed = (double)speed;
		int rob_rot = (int)env->home[id].rotation;

		double e = Kp*Geometry::DegAngleDiff( des_rot , rob_rot );
		

		// Max speed from distance-speed curve
		double v = max_speed;
		double V;

		if(e !=0){
				V = 180.0 / fabs(e);
		}else{
				// avoids division by 0
				V = 127.0;
		}
		
		if( abs(v) > V){ v = (v/abs(v)) *  V; }

		env->home[id].velocityLeft = - e;
		env->home[id].velocityRight = e;
}



#endif