// Strategy.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
//Add RSE includes here
#include <stdlib.h>
//#include <time.h>
//#include <math.h>

#include "StrategyUtils.h"
#include "Movement.h"
#include "FreeBall.h"
#include "FreeKick.h"
#include "GoalKick.h"
#include "KickOff.h"
#include "PenaltyKick.h"
#include "Development.h"

//Add your strategy include file here
//#include "YourStratFile.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
    return TRUE;
}

// Wizard - This is an example of an exported variable
STRATEGY_API int nStrategy=0;

// Wizard - This is an example of an exported function.
STRATEGY_API int fnStrategy(void)
{
	return 42;
}

// Wizard - This is the constructor of a class that has been exported.
// see Strategy.h for the class definition
CStrategy::CStrategy()
{ 
	return; 
}


//Must be defined - do NOT delete
extern "C" STRATEGY_API void Create ( Environment *env )
{	

}
//Must be defined - do NOT delete
extern "C" STRATEGY_API void Destroy ( Environment *env )
{

}

//Must be defined - do NOT delete
extern "C" STRATEGY_API void Strategy ( Environment *env )
{//Standard football interface
	//Uses mm for positions
	// Soccer Environment Specific
	RealEnvironment REnv;
	REnv = *(RealEnvironment*)env->userData;
	REnv.Speed = 10;		//Standard Speed

	// Fira: Strategy Coordinate System
	// All coords are in inches
	// 0 deg is facing forward (black triangle determines the front), and 
	// 0,0 is bottom right corner, when viewed behind the goal keeper.
	// + angles are anticlockwise 0,+180
	// - angles are clockwise 0,-180
	// This is applied in CMatch::Tick routine

	//Main control - put user functions here
	if (env->gameState == PLAY_GAME)
	{// Add the GameCode call here if all players are actioned
		//YourStratFileCall(env, REnv);
	}
	else
	{//Specific actions for fixed positions
		Player1(env, REnv);				//Goalie
		Player2(env, REnv);				//Defender1
		Player3(env, REnv);				//Defender2
		Player4(env, REnv);				//Attacker1
		Player5(env, REnv);				//Attacker2
	}
	UpdateObjectHistory(env);
}

void Player1(Environment *env, RealEnvironment REnv)
{
	REnv.RobotID = P1;	//Player1 - GREEN,green
	PlayerAction(env, REnv);
}

void Player2(Environment *env, RealEnvironment REnv)
{
	REnv.RobotID = P2;	//Player2 - CYAN,cyan
	PlayerAction(env, REnv);
}
void Player3(Environment *env, RealEnvironment REnv)
{
	REnv.RobotID = P3;	//Player3 - MAGENTA,magenta
	PlayerAction(env, REnv);
}

void Player4(Environment *env, RealEnvironment REnv)
{
	REnv.RobotID = P4;	//Player4 - MAGENTA,cyan
	PlayerAction(env, REnv);
}

void Player5(Environment *env, RealEnvironment REnv)
{
	REnv.RobotID = P5;	//Player5 - CYAN,magenta
	PlayerAction(env, REnv);
}

void PlayerAction(Environment *env, RealEnvironment REnv)
{
	//Player Specific Actions
	switch (env->gameState)
	{
	/*
	case PLAY_GAME:
		{// Add the GameCode call here if using specific actions for each player
		YourStratFileCall(env, REnv);
		}
		break;
	*/
	case FREE_BALL :
		{
		FreeBall(env, REnv);
		}
		break;
	case PLACE_KICK :
		{	
		KickOff(env, REnv);
		}
		break;
	case PENALTY_KICK :
		{
		PenaltyKick(env, REnv);
		}
		break;
	case FREE_KICK :
		{
		FreeKick(env, REnv);
		}
		break;
	case GOAL_KICK :
		{
		GoalKick(env, REnv);
		}
		break;
	case DEVELOPMENT :
		{
		Development(env, REnv);
		}
		break;
	default :
		{
		}
		break;
	}
}
#ifdef _TESTSTRATEGY

extern "C" STRATEGY_API void Strategy ( Environment *env )
{//Merlin 2 Points Strategy
	int RobotID = 0   , speed = 25;
	Vector3D target1 = {5,5};
	Vector3D target2 = {20,20};
	Vector3D currentTarget = {0,0};
	static int point = 0;
	bool bRes = false;

	if (point == 0)
	{
		currentTarget.x = target1.x;
		currentTarget.y = target1.y;
	}
	else
	{
		currentTarget.x = target2.x;
		currentTarget.y = target2.y;
	}


	int des_angle = (int)aimfor(RobotID , currentTarget, false , env);

	double dis= distance(currentTarget,env->home[RobotID].pos);


	if(dis<10)
	{
		int diffAngle = abs(d(des_angle, (int)env->home[RobotID].rotation));

		if ((diffAngle < 5) && (dis< 10))
			bRes = true;
		else
		{
			if(	(env->home[RobotID].velocityLeft<20) &&
				((diffAngle > 5) && 
				 (diffAngle < 175)))
			{
				RotateTo(des_angle , speed, RobotID,  env ,true);
			}
			else
			{
				MoveTo( des_angle , speed, RobotID ,env , true);
			}
		}
		
	}
	else
	{
		MoveToOld( des_angle , speed, RobotID ,env , true);
	}

	UpdateObjectHistory(env);

	// move to the next position
	if (bRes)
	{
		if (point == 0)
			point = 1;
		else 
			point = 0;
	}
}
#endif


