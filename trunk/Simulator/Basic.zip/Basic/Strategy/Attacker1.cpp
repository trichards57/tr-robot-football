#include "stdafx.h"
#include "StrategyUtils.h"
#include "Movement.h"



void Attacker1(Environment *env, RealEnvironment REnv)
{//Green corner
}