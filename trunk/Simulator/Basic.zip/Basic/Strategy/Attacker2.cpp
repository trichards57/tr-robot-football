#include "stdafx.h"
#include "StrategyUtils.h"
#include "Movement.h"



void Attacker2(Environment *env, RealEnvironment REnv)
{//Cyan Corner
}
