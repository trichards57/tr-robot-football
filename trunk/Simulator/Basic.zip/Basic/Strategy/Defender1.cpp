#include "stdafx.h"
#include "StrategyUtils.h"
#include "Movement.h"


void Defender1(Environment *env, RealEnvironment REnv)
{//Violet corner
}