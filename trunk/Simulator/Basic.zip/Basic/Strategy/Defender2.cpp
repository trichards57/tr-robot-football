#include "stdafx.h"
#include "StrategyUtils.h"
#include "Movement.h"



void Defender2(Environment *env, RealEnvironment REnv)
{//Magenta corner
}

