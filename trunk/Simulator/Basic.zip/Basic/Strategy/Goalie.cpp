#include "stdafx.h"
#include "StrategyUtils.h"
#include "Movement.h"
#include "Sim.h"


void Goalie(Environment *env, RealEnvironment REnv)
{//Red corner
}
