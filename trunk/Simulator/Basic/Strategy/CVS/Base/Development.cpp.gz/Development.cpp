#include "stdafx.h"
#include "StrategyUtils.h"
#include "Movement.h"
#include "Development.h"

void Development(Environment *env, RealEnvironment REnv)
{//Common Entry Point for Development Option from RSE Game Tab

}
