#include "stdafx.h"
#include "StrategyUtils.h"
#include "Movement.h"
#include "FreeBall.h"

void FreeBall(Environment *env, RealEnvironment REnv)
{
	Vector2d Target;

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	int Position = REnv.Position;
	switch (Position)
	{
	case BOTTOM_LEFT :
		{//bottom left kick
			if (REnv.PlayTo == RIGHT_SIDE)
				BottomLeftKickL2R(env, REnv, &Target);
			else
				BottomLeftKickR2L(env, REnv, &Target);
		}
		break;
	case BOTTOM_RIGHT :
		{//bottom right kick
			if (REnv.PlayTo == RIGHT_SIDE)
				BottomRightKickL2R(env, REnv, &Target);
			else
				BottomRightKickR2L(env, REnv, &Target);
		}
		break;
	case TOP_LEFT :
		{//top left kick
			if (REnv.PlayTo == RIGHT_SIDE)
				TopLeftKickL2R(env, REnv, &Target);
			else
				TopLeftKickR2L(env, REnv, &Target);
		}
		break;
	case TOP_RIGHT :
		{//top right kick
			if (REnv.PlayTo == RIGHT_SIDE)
				TopRightKickL2R(env, REnv, &Target);
			else
				TopRightKickR2L(env, REnv, &Target);
		}
		break;
	}
	
	Target.m_x = Target.m_x/FIRA_LENGTH*PITCH_LENGTH/25.4;
	Target.m_y = Target.m_y/FIRA_WIDTH*PITCH_WIDTH/25.4;
	NavigateTo(env, REnv, Target);
}

void BottomLeftKickL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line near left post
			Target->m_x = 100;
			Target->m_y = 1050;
			Target->m_degphi = 45;
		}
		break;
	case P2 :
		{//Kicker - bottom left cross
			Target->m_x = 262;
			Target->m_y = 1500;
		}
		break;
	case P3 :
		{//bottom right PA
			Target->m_x = 300;
			Target->m_y = 850;
			Target->m_degphi = 75;
		}
		break;
	case P4 :
		{//bottom right opposite ball
			Target->m_x = 550;
			Target->m_y = 850;
			Target->m_degphi = 90;
		}
		break;
	case P5 :
		{//top left quadrant
			Target->m_x = 1150;
			Target->m_y = 1300;
		}
		break;
	default :
		{
		}
		break;
	}
}

void BottomRightKickL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{// On goal line near right post
			Target->m_x = 100;
			Target->m_y = 750;
			Target->m_degphi = -45;
		}
		break;
	case P2 :
		{//bottom left PA
			Target->m_x = 300;
			Target->m_y = 950;
			Target->m_degphi = -15;
		}
		break;
	case P3 :
		{//Kicker bottom right cross
			Target->m_x = 262;
			Target->m_y = 300;
		}
		break;
	case P4 :
		{//bottom left opposite ball
			Target->m_x = 550;
			Target->m_y = 950;
			Target->m_degphi = -90;
		}
		break;
	case P5 :
		{//top right quadrant
			Target->m_x = 1150;
			Target->m_y = 500;
		}
		break;
	default :
		{
		}
		break;
	}
}

void TopLeftKickL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{	
	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line opposite penalty spot
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//bottom left quadrant
			Target->m_x = 1050;
			Target->m_y = 1300;
					}
		break;
	case P3 :
		{//bottom right quadrant
			Target->m_x = 800;
			Target->m_y = 800;
			Target->m_degphi = 45;
		}
		break;
	case P4 :
		{//Kicker - top left cross
			Target->m_x = 1362;
			Target->m_y = 1500;
		}
		break;
	case P5 :
		{//top right opposite ball
			Target->m_x = 1650;
			Target->m_y = 850;
			Target->m_degphi = 90;
		}
		break;
	default :
		{
		}
		break;
	}
}

void TopRightKickL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{	
	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line opposite penalty spot
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//bottom left quadrant
			Target->m_x = 800;
			Target->m_y = 1000;
			Target->m_degphi = -45;
		}
		break;
	case P3 :
		{//bottom right quadrant
			Target->m_x = 1050;
			Target->m_y = 500;
					}
		break;
	case P4 :
		{//Kicker - top right cross
			Target->m_x = 1362;
			Target->m_y = 300;
		}
		break;
	case P5 :
		{//top left opposite ball
			Target->m_x = 1650;
			Target->m_y = 950;
			Target->m_degphi = -90;
		}
		break;
	default :
		{
		}
		break;
	}
}

void BottomLeftKickR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line near left post
			Target->m_x = 100;
			Target->m_y = 1050;
			Target->m_degphi = -135;
		}
		break;
	case P2 :
		{//Kicker - bottom left cross
			Target->m_x = 262;
			Target->m_y = 1500;
		}
		break;
	case P3 :
		{//bottom right PA
			Target->m_x = 300;
			Target->m_y = 850;
			Target->m_degphi = -105;
		}
		break;
	case P4 :
		{//bottom right opposite ball
			Target->m_x = 550;
			Target->m_y = 850;
			Target->m_degphi = -90;
		}
		break;
	case P5 :
		{//top left quadrant
			Target->m_x = 1150;
			Target->m_y = 1300;
		}
		break;
	default :
		{
		}
		break;
	}
}

void BottomRightKickR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{// On goal line near right post
			Target->m_x = 100;
			Target->m_y = 750;
			Target->m_degphi = 135;
		}
		break;
	case P2 :
		{//bottom left PA
			Target->m_x = 300;
			Target->m_y = 950;
			Target->m_degphi = 105;
		}
		break;
	case P3 :
		{//Kicker bottom right cross
			Target->m_x = 262;
			Target->m_y = 300;
		}
		break;
	case P4 :
		{//bottom left opposite ball
			Target->m_x = 550;
			Target->m_y = 950;
			Target->m_degphi = 90;
		}
		break;
	case P5 :
		{//top right quadrant
			Target->m_x = 1150;
			Target->m_y = 500;
		}
		break;
	default :
		{
		}
		break;
	}
}

void TopLeftKickR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{	
	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line opposite penalty spot
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//bottom left quadrant
			Target->m_x = 1050;
			Target->m_y = 1300;
		}
		break;
	case P3 :
		{//bottom right quadrant
			Target->m_x = 800;
			Target->m_y = 800;
			Target->m_degphi = -135;
		}
		break;
	case P4 :
		{//Kicker - top left cross
			Target->m_x = 1362;
			Target->m_y = 1500;
		}
		break;
	case P5 :
		{//top right opposite ball
			Target->m_x = 1650;
			Target->m_y = 850;
			Target->m_degphi = -90;
		}
		break;
	default :
		{
		}
		break;
	}
}

void TopRightKickR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{	
	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line opposite penalty spot
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//bottom left quadrant
			Target->m_x = 800;
			Target->m_y = 1000;
			Target->m_degphi = 135;
		}
		break;
	case P3 :
		{//bottom right quadrant
			Target->m_x = 1050;
			Target->m_y = 500;
					}
		break;
	case P4 :
		{//Kicker - top right cross
			Target->m_x = 1362;
			Target->m_y = 300;
		}
		break;
	case P5 :
		{//top left opposite ball
			Target->m_x = 1650;
			Target->m_y = 950;
			Target->m_degphi = 90;
		}
		break;
	default :
		{
		}
		break;
	}
}


