
void FreeBall(Environment *env, RealEnvironment REnv);
void BottomLeftKickL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void BottomRightKickL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void TopLeftKickL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void TopRightKickL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void BottomLeftKickR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void BottomRightKickR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void TopLeftKickR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void TopRightKickR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);

