
void FreeKick(Environment *env, RealEnvironment REnv);
void FreeKickAtkL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void FreeKickAtkR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void FreeKickDefL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void FreeKickDefR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void BottomRightKickAtkL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void BottomRightKickAtkR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void BottomRightKickDefL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void BottomRightKickDefR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void TopRightKickAtkL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void TopRightKickAtkR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void TopRightKickDefL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void TopRightKickDefR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void BottomLeftKickAtkL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void BottomLeftKickAtkR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void BottomLeftKickDefL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void BottomLeftKickDefR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void TopLeftKickAtkL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void TopLeftKickAtkR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);
void TopLeftKickDefL2R(Environment *env, RealEnvironment REnv, Vector2d *Target);
void TopLeftKickDefR2L(Environment *env, RealEnvironment REnv, Vector2d *Target);

