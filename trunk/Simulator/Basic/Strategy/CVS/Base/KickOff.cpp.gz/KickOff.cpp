#include "stdafx.h"
#include "StrategyUtils.h"
#include "Movement.h"
#include "KickOff.h"

void KickOff(Environment *env, RealEnvironment REnv)
{
	Vector2d Target;

	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	if (REnv.PlayTo == RIGHT_SIDE)
		if (REnv.IsBlueTeam) 
			if (env->whosBall == BLUE_BALL)
				KickOffAtkL2R(env, REnv, &Target);
			else
				KickOffDefL2R(env, REnv, &Target);
		else
			if (env->whosBall == YELLOW_BALL)
				KickOffAtkL2R(env, REnv, &Target);
			else
				KickOffDefL2R(env, REnv, &Target);
	else
		if (REnv.IsBlueTeam) 
			if (env->whosBall == BLUE_BALL)
				KickOffAtkR2L(env, REnv, &Target);
			else
				KickOffDefR2L(env, REnv, &Target);
		else
			if (env->whosBall == YELLOW_BALL)
				KickOffAtkR2L(env, REnv, &Target);
			else
				KickOffDefR2L(env, REnv, &Target);

	//To make compatible with the FIRA Simulator
	Target.m_x = Target.m_x/FIRA_LENGTH*PITCH_LENGTH/25.4;
	Target.m_y = Target.m_y/FIRA_WIDTH*PITCH_WIDTH/25.4;
	NavigateTo(env, REnv, Target);
}

void KickOffAtkL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line opposite penalty spot
			Target->m_x = 100;
			Target->m_y = 900;		// in mm
		}
		break;
	case P2 :
		{//bottom left quadrant
			Target->m_x = 800;
			Target->m_y = 1200;
		}
		break;
	case P3 :
		{//bottom right quadrant
			Target->m_x = 800;
			Target->m_y = 600;
		}
		break;
	case P4 :
		{//Receiver
			Target->m_x = 1000;
			Target->m_y = 900;
			Target->m_degphi = 30;
		}
		break;
	case P5 :
		{//Kicker
			Target->m_x = 1150;
			Target->m_y = 850;
			Target->m_degphi = 150;
		}
		break;
	default :
		{
		}
		break;
	}
}

void KickOffAtkR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 180;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line opposite penalty spot
			Target->m_x = 100;
			Target->m_y = 900;		// in mm
		}
		break;
	case P2 :
		{//bottom left quadrant
			Target->m_x = 800;
			Target->m_y = 1200;
		}
		break;
	case P3 :
		{//bottom right quadrant
			Target->m_x = 800;
			Target->m_y = 600;
		}
		break;
	case P4 :
		{//Receiver
			Target->m_x = 1000;
			Target->m_y = 900;
			Target->m_degphi = -150;
		}
		break;
	case P5 :
		{//Kicker
			Target->m_x = 1150;
			Target->m_y = 850;
			Target->m_degphi = -30;
		}
		break;
	default :
		{
		}
		break;
	}
}

void KickOffDefL2R(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 0;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line opposite penalty spot
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//bottom left quadrant
			Target->m_x = 500;
			Target->m_y = 1100;
		}
		break;
	case P3 :
		{//bottom right quadrant
			Target->m_x = 500;
			Target->m_y = 700;
		}
		break;
	case P4 :
		{//bottom left quadrant
			Target->m_x = 810;
			Target->m_y = 1000;
		}
		break;
	case P5 :
		{//bottom right quadrant
			Target->m_x = 810;
			Target->m_y = 800;
		}
		break;
	default :
		{
		}
		break;
	}
}


void KickOffDefR2L(Environment *env, RealEnvironment REnv, Vector2d *Target)
{
	//Viewed from behind the goal keeper: Top > 1100 for x; Left > 900 for y
	Target->m_degphi = 180;
	switch (REnv.RobotID)
	{
	case P1 :
		{//On goal line opposite penalty spot
			Target->m_x = 100;
			Target->m_y = 900;
		}
		break;
	case P2 :
		{//bottom left quadrant
			Target->m_x = 500;
			Target->m_y = 1100;
		}
		break;
	case P3 :
		{//bottom right quadrant
			Target->m_x = 500;
			Target->m_y = 700;
		}
		break;
	case P4 :
		{//bottom left quadrant
			Target->m_x = 810;
			Target->m_y = 1000;
		}
		break;
	case P5 :
		{//bottom right quadrant
			Target->m_x = 810;
			Target->m_y = 800;
		}
		break;
	default :
		{
		}
		break;
	}
}

