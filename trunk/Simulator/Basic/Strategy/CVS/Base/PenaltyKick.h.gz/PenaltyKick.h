void PenaltyKick(Environment *env, RealEnvironment REnv);
void PenaltyAtk(Environment *env, RealEnvironment REnv, Vector2d *Target);
void PenaltyDef(Environment *env, RealEnvironment REnv, Vector2d *Target);

